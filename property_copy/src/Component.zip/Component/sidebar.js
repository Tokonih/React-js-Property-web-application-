// import { Sidebar } from "react-pro-sidebar";

import SidebartItem from "./SidebarItem";

export default function Sidebar(){
    return(
        <div className="sidebar">
            <SidebartItem/>
        </div>
    )
}